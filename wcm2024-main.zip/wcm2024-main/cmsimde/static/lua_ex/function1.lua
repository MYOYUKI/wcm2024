function function1()
    return [[
function myfun(n)
    for i = 1, n do
        print(i)
    end
end

myfun(5)
    ]]
end  
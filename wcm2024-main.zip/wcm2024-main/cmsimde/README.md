# cmsimde
cmsimde main scripts

for Replit:

git submodule update --init --recursive 

pip install flask flask_cors bs4 lxml pelican markdown gevent
